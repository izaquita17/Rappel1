<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Rappel Extreme - Experiencias de Aventura</title>
  <link rel="shortcut icon" href="favicon.ico">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
<!-- bxslider -->
<link type="text/css" rel='stylesheet' href="js/bxslider/jquery.bxslider.css">
<!-- End bxslider -->
<!-- flexslider -->
<link type="text/css" rel='stylesheet' href="js/flexslider/flexslider.css">
<!-- End flexslider -->

<!-- bxslider -->
<link type="text/css" rel='stylesheet' href="js/radial-progress/style.css">
<!-- End bxslider -->

<!-- Animate css -->
<link type="text/css" rel='stylesheet' href="css/animate.css">
<!-- End Animate css -->

<!-- Bootstrap css -->
<link type="text/css" rel='stylesheet' href="css/bootstrap.min.css">
<link type="text/css" rel='stylesheet' href="js/bootstrap-progressbar/bootstrap-progressbar-3.2.0.min.css">
<!-- End Bootstrap css -->

<!-- Jquery UI css -->
<link type="text/css" rel='stylesheet' href="js/jqueryui/jquery-ui.css">
<link type="text/css" rel='stylesheet' href="js/jqueryui/jquery-ui.structure.css">
<!-- End Jquery UI css -->

<!-- Fancybox -->
<link type="text/css" rel='stylesheet' href="js/fancybox/jquery.fancybox.css">
<!-- End Fancybox -->

<link type="text/css" rel='stylesheet' href="fonts/fonts.css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&subset=latin,cyrillic-ext' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

<link type="text/css" data-themecolor="default" rel='stylesheet' href="css/main-default.css">

<link type="text/css" rel='stylesheet' href="js/rs-plugin/css/settings.css">
<link type="text/css" rel='stylesheet' href="js/rs-plugin/css/settings-custom.css">
<link type="text/css" rel='stylesheet' href="js/rs-plugin/videojs/video-js.css">
</head>
<body>
  <div class="mask-l" style="background-color: #fff; width: 100%; height: 100%; position: fixed; top: 0; left:0; z-index: 9999999;"></div> <!--removed by integration-->
<header>
  <div class="container b-header__box b-relative">
    <a href="homepage-1_index_travel.html" class="b-left b-logo"><img class="color-theme" data-retina src="img/logo-header-default.png" alt="Rappel Extreme" /></a>
    <div class="b-header-r b-right b-header-r--icon">
      <div class="b-header-ico-group f-header-ico-group b-right">
          <span class="b-search-box">
              <i class="fa fa-search"></i>
              <input type="text" placeholder="Buscar actividades..."/>
          </span>
      </div>
      <div class="b-top-nav-show-slide f-top-nav-show-slide b-right j-top-nav-show-slide"><i class="fa fa-align-justify"></i></div>
      <nav class="b-top-nav f-top-nav b-right j-top-nav">
          <ul class="b-top-nav__1level_wrap">
              <li class="b-top-nav__1level f-top-nav__1level f-primary-b"><a href="index.php"><i class="fa fa-home b-menu-1level-ico"></i>Inicio</a></li>
              <li class="b-top-nav__1level f-top-nav__1level f-primary-b"><a href="sobre_nosotros.html"><i class="fa fa-users b-menu-1level-ico"></i>Quiénes Somos</a></li>
              <li class="b-top-nav__1level f-top-nav__1level f-primary-b"><a href="galeria.html"><i class="fa fa-camera b-menu-1level-ico"></i>Galería</a></li>
              <li class="b-top-nav__1level f-top-nav__1level f-primary-b"><a href="contacto.html"><i class="fa fa-envelope b-menu-1level-ico"></i>Contacto</a></li>
              <li class="b-top-nav__1level f-top-nav__1level f-primary-b"><a href="reserva.html"><i class="fa fa-calendar b-menu-1level-ico"></i>Reserva</a></li>
          </ul>
      </nav>
    </div>
  </div>
</header>
<div class="j-menu-container"></div>


  <div class="l-main-container">



    <div class="b-slidercontainer b-slider b-slider--thumb">
      <div class=" j-fullscreenslider j-arr-nexttobullets">
          <ul>
              <li data-transition="slotfade-vertical" data-slotamount="7" >
                  <div class="tp-bannertimer"></div>
                  <img data-retina src="img/slider/section-bg-4.jpg">
                  <div class="caption lft caption-left"  data-x="left" data-y="150" data-hoffset="60" data-speed="700" data-start="2000">
                      <div class="b-slider-lg-info-l__item-title f-slider-lg-info-l__item-title b-slider-lg-info-l__item-title-tertiary b-bg-slider-lg-info-l__item-title">
                          <h2 class="f-primary-l">Rappel Extreme</h2>
                          <h1 class="f-primary-b">Aventura y Naturaleza</h1>
                      </div>
                  </div>
                  <div class="caption lfl caption-left"  data-x="left" data-y="270" data-speed="1000" data-start="2600">
                      <div class="b-slider-lg-info-l__item-link f-slider-lg-info-l__item-link">
                          <a href="#" class="b-slider-lg-info-l__item-anchor f-slider-lg-info-l__item-anchor f-primary-b">Descubre la emoción del descenso</a>
                          <span class="b-slider-lg-info-l__item-link-after"><i class="fa fa-chevron-right"></i></span>
                      </div>
                  </div>
              </li>
              <li data-transition="" data-slotamount="10" >
                  <div class="tp-bannertimer"></div>
                  <img data-retina src="img/slider/slider-section-2.jpg">
                  <div class="caption lft caption-left"  data-x="left" data-y="100" data-hoffset="60" data-speed="700" data-start="2000">
                      <div class="b-slider-lg-info-l__item-title f-slider-lg-info-l__item-title b-slider-lg-info-l__item-title-tertiary">
                          <h2 class="f-primary-l">Rappel Extreme</h2>
                          <h1 class="f-primary-b">Experiencias Únicas</h1>
                          <p>Descubre la adrenalina y la belleza de la naturaleza<br /> en nuestras actividades de aventura</p>
                      </div>
                  </div>
                  <div class="caption lfl caption-left"  data-x="left" data-y="270" data-speed="1000" data-start="2600">
                      <div class="b-slider-lg-info-l__item-link f-slider-lg-info-l__item-link">
                          <a href="#" class="b-slider-lg-info-l__item-anchor f-slider-lg-info-l__item-anchor f-primary-b">Explora nuestras actividades</a>
                          <span class="b-slider-lg-info-l__item-link-after"><i class="fa fa-chevron-right"></i></span>
                      </div>
                  </div>
              </li>
              <li data-transition="" data-slotamount="10" >
                  <div class="tp-bannertimer"></div>
                  <img data-retina src="img/slider/slider-section-3.jpg">
                  <div class="caption lft caption-left"  data-x="left" data-y="100" data-hoffset="60" data-speed="700" data-start="2000">
                      <div class="b-slider-lg-info-l__item-title f-slider-lg-info-l__item-title b-slider-lg-info-l__item-title-tertiary">
                          <h2 class="f-primary-l">Rappel Extreme</h2>
                          <h1 class="f-primary-b">Aventura Segura</h1>
                          <p>Equipamiento profesional y guías certificados<br /> para una experiencia segura y emocionante</p>
                      </div>
                  </div>
                  <div class="caption lfl caption-left"  data-x="left" data-y="270" data-speed="1000" data-start="2600">
                      <div class="b-slider-lg-info-l__item-link f-slider-lg-info-l__item-link">
                          <a href="#" class="b-slider-lg-info-l__item-anchor f-slider-lg-info-l__item-anchor f-primary-b">Reserva tu aventura</a>
                          <span class="b-slider-lg-info-l__item-link-after"><i class="fa fa-chevron-right"></i></span>
                      </div>
                  </div>
              </li>
          </ul>
      </div>
    </div>

    <section class="b-infoblock">
      <div class="container">
        <div class="b-search-map">
          <div class="j-tabs b-tabs-reset b-search-map-tabs">
            <div class="b-search-map_header">
              <div class="b-search-map__title f-search-map__title f-primary-b">Quick search</div>
              <ul class="b-search-map__tabs-anchor f-search-map__tabs-anchor">
                <li><a class="f-primary-b" href="#tabs-1">TOURS</a></li>
                <li><a class="f-primary-b" href="#tabs-2">HOTELS</a></li>
                <li><a class="f-primary-b" href="#tabs-3">FLIGHS</a></li>
                <li><a class="f-primary-b" href="#tabs-4">CARS</a></li>
              </ul>
            </div>
            <div id="tabs-1">
              <div class="b-search-map__wrap">
                <form method="get" action="/" class="b-form f-form b-form-inline f-form-inline">
                  <div class="b-search-map__name f-search-map__name">
                    <span class="b-search-map__name_hight f-search-map__name_hight f-primary-b">book</span><br/>
                    your tours
                  </div>
                  <div class="b-search-map__fields f-search-map__fields">
                    <div class="b-form-group">
                      <label class="f-primary-b" for="tourLocation">Tour location</label>
                      <input type="text" class="b-form-control" id="tourLocation">
                    </div>
                    <div class="b-form-group">
                      <label class="f-primary-b" for="startDate">Start date</label>
                      <div class="b-form-control__icon-wrap">
                        <input type="text" class="b-form-control datepicker" id="startDate">
                        <i class="fa fa-calendar b-form-control__icon f-form-control__icon"></i>
                      </div>
                    </div>
                    <div class="b-form-group">
                      <label class="f-primary-b" for="guests">guests</label>
                      <input type="text" class="b-form-control" id="guests">
                    </div>
                    <div class="b-form-group">
                      <label class="f-primary-b">find tour</label>
                      <button class="b-search-map__submit b-btn f-btn b-btn-light f-btn-light f-primary-b">search</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <div id="tabs-2">
              <div class="b-search-map__wrap">
                <form method="get" action="/" class="b-form f-form b-form-inline f-form-inline">
                  <div class="b-search-map__name f-search-map__name">
                    <span class="b-search-map__name_hight f-search-map__name_hight f-primary-b">book</span><br/>
                    your hotels
                  </div>
                  <div class="b-search-map__fields f-search-map__fields">
                    <div class="b-form-group">
                      <label class="f-primary-b" for="tourLocation">hotel location</label>
                      <input type="text" class="b-form-control" id="hotelLocation">
                    </div>
                    <div class="b-form-group">
                      <label class="f-primary-b" for="startDate">Start date</label>
                      <div class="b-form-control__icon-wrap">
                        <input type="text" class="b-form-control datepicker" id="startDate_hotel">
                        <i class="fa fa-calendar b-form-control__icon f-form-control__icon"></i>
                      </div>
                    </div>
                    <div class="b-form-group">
                      <label class="f-primary-b" for="guests">guests</label>
                      <input type="text" class="b-form-control" id="guests_hotel">
                    </div>
                    <div class="b-form-group">
                      <label class="f-primary-b">find hotel</label>
                      <button class="b-search-map__submit b-btn f-btn b-btn-light f-btn-light f-primary-b">search</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <div id="tabs-3">
              <div class="b-search-map__wrap">
                <form method="get" action="/" class="b-form f-form b-form-inline f-form-inline">
                  <div class="b-search-map__name f-search-map__name">
                    <span class="b-search-map__name_hight f-search-map__name_hight f-primary-b">book</span><br/>
                    your flighs
                  </div>
                  <div class="b-search-map__fields f-search-map__fields">
                    <div class="b-form-group">
                      <label class="f-primary-b" for="tourLocation">fligh location</label>
                      <input type="text" class="b-form-control" id="flighLocation">
                    </div>
                    <div class="b-form-group">
                      <label class="f-primary-b" for="startDate">Start date</label>
                      <div class="b-form-control__icon-wrap">
                        <input type="text" class="b-form-control datepicker" id="startDate_fligh">
                        <i class="fa fa-calendar b-form-control__icon f-form-control__icon"></i>
                      </div>
                    </div>
                    <div class="b-form-group">
                      <label class="f-primary-b" for="guests">guests</label>
                      <input type="text" class="b-form-control" id="guests_fligh">
                    </div>
                    <div class="b-form-group">
                      <label class="f-primary-b">find fligh</label>
                      <button class="b-search-map__submit b-btn f-btn b-btn-light f-btn-light f-primary-b">search</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <div id="tabs-4">
              <div class="b-search-map__wrap">
                <form method="get" action="/" class="b-form f-form b-form-inline f-form-inline clearfix">
                  <div class="b-search-map__name f-search-map__name">
                    <span class="b-search-map__name_hight f-search-map__name_hight f-primary-b">book</span><br/>
                    your cars
                  </div>
                  <div class="b-search-map__fields f-search-map__fields">
                    <div class="b-form-group">
                      <label class="f-primary-b" for="tourLocation">car location</label>
                      <input type="text" class="b-form-control" id="carLocation">
                    </div>
                    <div class="b-form-group">
                      <label class="f-primary-b" for="startDate">Start date</label>
                      <div class="b-form-control__icon-wrap">
                        <input type="text" class="b-form-control datepicker" id="startDate_car">
                        <i class="fa fa-calendar b-form-control__icon f-form-control__icon"></i>
                      </div>
                    </div>
                    <div class="b-form-group">
                      <label class="f-primary-b" for="guests">guests</label>
                      <input type="text" class="b-form-control" id="guests_car">
                    </div>
                    <div class="b-form-group">
                      <label class="f-primary-b">find car</label>
                      <button class="b-search-map__submit b-btn f-btn b-btn-light f-btn-light f-primary-b">search</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="b-infoblock b-diagonal-line-bg-light">
      <div class="container">
        <div class="b-carousel-secondary f-carousel-secondary b-some-examples-tertiary f-some-examples-tertiary b-carousel-reset">
          <div class="b-carousel-title f-carousel-title f-primary-b">special offers</div>
          <div class="b-some-examples f-some-examples j-carousel-secondary">
              <div class="b-some-examples__item f-some-examples__item">
    <div class="b-some-examples__item_img view view-sixth">
    <img data-retina="" src="img/homepage/travel_img1.jpg" alt="">
    <div class="b-item-hover-action f-center mask">
        <div class="b-item-hover-action__inner">
            <div class="b-item-hover-action__inner-btn_group">
                <a href="#" class="b-btn f-btn b-btn-light f-btn-light info"><i class="fa fa-link"></i></a>
            </div>
        </div>
    </div>
</div>
    <div class="b-some-examples__item_info">
        <div class="b-some-examples__item_info_level b-some-examples__item_name f-some-examples__item_name f-primary-b"><a href="#">Tropicana hotel</a></div>
        <div class="b-some-examples__item_info_level b-some-examples__item_double_info f-some-examples__item_double_info clearfix">
            <div class="b-stars-group f-stars-group">
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star"></i>
</div>
        </div>
        <div class="b-some-examples__item_info_level b-some-examples__item_description f-some-examples__item_description">
            Suspendisse blandit ligula turpis, ac convallis risus fermentum non. Duis vestibulum quis quam vel accumsan. Nunc a vulputate lectus.
        </div>
    </div>
    <div class="b-some-examples__item_action">
        <div class="b-right">
            <a href="#" class="b-btn f-btn b-btn-sm f-btn-sm b-btn-default f-primary-b">book now</a>
        </div>
        <div class="b-remaining b-some-examples__item_total f-some-examples__item_total f-primary-b">From $1299</div>
    </div>
</div>
              <div class="b-some-examples__item f-some-examples__item">
    <div class="b-some-examples__item_img view view-sixth">
    <img data-retina="" src="img/homepage/travel_img2.jpg" alt="">
    <div class="b-item-hover-action f-center mask">
        <div class="b-item-hover-action__inner">
            <div class="b-item-hover-action__inner-btn_group">
                <a href="#" class="b-btn f-btn b-btn-light f-btn-light info"><i class="fa fa-link"></i></a>
            </div>
        </div>
    </div>
</div>
    <div class="b-some-examples__item_info">
        <div class="b-some-examples__item_info_level b-some-examples__item_name f-some-examples__item_name f-primary-b"><a href="#">Tropicana hotel</a></div>
        <div class="b-some-examples__item_info_level b-some-examples__item_double_info f-some-examples__item_double_info clearfix">
            <div class="b-stars-group f-stars-group">
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star"></i>
</div>
        </div>
        <div class="b-some-examples__item_info_level b-some-examples__item_description f-some-examples__item_description">
            Suspendisse blandit ligula turpis, ac convallis risus fermentum non. Duis vestibulum quis quam vel accumsan. Nunc a vulputate lectus.
        </div>
    </div>
    <div class="b-some-examples__item_action">
        <div class="b-right">
            <a href="#" class="b-btn f-btn b-btn-sm f-btn-sm b-btn-default f-primary-b">book now</a>
        </div>
        <div class="b-remaining b-some-examples__item_total f-some-examples__item_total f-primary-b">From $1299</div>
    </div>
</div>
              <div class="b-some-examples__item f-some-examples__item">
    <div class="b-some-examples__item_img view view-sixth">
    <img data-retina="" src="img/homepage/travel_img3.jpg" alt="">
    <div class="b-item-hover-action f-center mask">
        <div class="b-item-hover-action__inner">
            <div class="b-item-hover-action__inner-btn_group">
                <a href="#" class="b-btn f-btn b-btn-light f-btn-light info"><i class="fa fa-link"></i></a>
            </div>
        </div>
    </div>
</div>
    <div class="b-some-examples__item_info">
        <div class="b-some-examples__item_info_level b-some-examples__item_name f-some-examples__item_name f-primary-b"><a href="#">Tropicana hotel</a></div>
        <div class="b-some-examples__item_info_level b-some-examples__item_double_info f-some-examples__item_double_info clearfix">
            <div class="b-stars-group f-stars-group">
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star"></i>
</div>
        </div>
        <div class="b-some-examples__item_info_level b-some-examples__item_description f-some-examples__item_description">
            Suspendisse blandit ligula turpis, ac convallis risus fermentum non. Duis vestibulum quis quam vel accumsan. Nunc a vulputate lectus.
        </div>
    </div>
    <div class="b-some-examples__item_action">
        <div class="b-right">
            <a href="#" class="b-btn f-btn b-btn-sm f-btn-sm b-btn-default f-primary-b">book now</a>
        </div>
        <div class="b-remaining b-some-examples__item_total f-some-examples__item_total f-primary-b">From $1299</div>
    </div>
</div>
              <div class="b-some-examples__item f-some-examples__item">
    <div class="b-some-examples__item_img view view-sixth">
    <img data-retina="" src="img/homepage/travel_img1.jpg" alt="">
    <div class="b-item-hover-action f-center mask">
        <div class="b-item-hover-action__inner">
            <div class="b-item-hover-action__inner-btn_group">
                <a href="#" class="b-btn f-btn b-btn-light f-btn-light info"><i class="fa fa-link"></i></a>
            </div>
        </div>
    </div>
</div>
    <div class="b-some-examples__item_info">
        <div class="b-some-examples__item_info_level b-some-examples__item_name f-some-examples__item_name f-primary-b"><a href="#">Tropicana hotel</a></div>
        <div class="b-some-examples__item_info_level b-some-examples__item_double_info f-some-examples__item_double_info clearfix">
            <div class="b-stars-group f-stars-group">
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star"></i>
</div>
        </div>
        <div class="b-some-examples__item_info_level b-some-examples__item_description f-some-examples__item_description">
            Suspendisse blandit ligula turpis, ac convallis risus fermentum non. Duis vestibulum quis quam vel accumsan. Nunc a vulputate lectus.
        </div>
    </div>
    <div class="b-some-examples__item_action">
        <div class="b-right">
            <a href="#" class="b-btn f-btn b-btn-sm f-btn-sm b-btn-default f-primary-b">book now</a>
        </div>
        <div class="b-remaining b-some-examples__item_total f-some-examples__item_total f-primary-b">From $1299</div>
    </div>
</div>
              <div class="b-some-examples__item f-some-examples__item">
    <div class="b-some-examples__item_img view view-sixth">
    <img data-retina="" src="img/homepage/travel_img2.jpg" alt="">
    <div class="b-item-hover-action f-center mask">
        <div class="b-item-hover-action__inner">
            <div class="b-item-hover-action__inner-btn_group">
                <a href="#" class="b-btn f-btn b-btn-light f-btn-light info"><i class="fa fa-link"></i></a>
            </div>
        </div>
    </div>
</div>
    <div class="b-some-examples__item_info">
        <div class="b-some-examples__item_info_level b-some-examples__item_name f-some-examples__item_name f-primary-b"><a href="#">Tropicana hotel</a></div>
        <div class="b-some-examples__item_info_level b-some-examples__item_double_info f-some-examples__item_double_info clearfix">
            <div class="b-stars-group f-stars-group">
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star"></i>
</div>
        </div>
        <div class="b-some-examples__item_info_level b-some-examples__item_description f-some-examples__item_description">
            Suspendisse blandit ligula turpis, ac convallis risus fermentum non. Duis vestibulum quis quam vel accumsan. Nunc a vulputate lectus.
        </div>
    </div>
    <div class="b-some-examples__item_action">
        <div class="b-right">
            <a href="#" class="b-btn f-btn b-btn-sm f-btn-sm b-btn-default f-primary-b">book now</a>
        </div>
        <div class="b-remaining b-some-examples__item_total f-some-examples__item_total f-primary-b">From $1299</div>
    </div>
</div>
              <div class="b-some-examples__item f-some-examples__item">
    <div class="b-some-examples__item_img view view-sixth">
    <img data-retina="" src="img/homepage/travel_img3.jpg" alt="">
    <div class="b-item-hover-action f-center mask">
        <div class="b-item-hover-action__inner">
            <div class="b-item-hover-action__inner-btn_group">
                <a href="#" class="b-btn f-btn b-btn-light f-btn-light info"><i class="fa fa-link"></i></a>
            </div>
        </div>
    </div>
</div>
    <div class="b-some-examples__item_info">
        <div class="b-some-examples__item_info_level b-some-examples__item_name f-some-examples__item_name f-primary-b"><a href="#">Tropicana hotel</a></div>
        <div class="b-some-examples__item_info_level b-some-examples__item_double_info f-some-examples__item_double_info clearfix">
            <div class="b-stars-group f-stars-group">
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star"></i>
</div>
        </div>
        <div class="b-some-examples__item_info_level b-some-examples__item_description f-some-examples__item_description">
            Suspendisse blandit ligula turpis, ac convallis risus fermentum non. Duis vestibulum quis quam vel accumsan. Nunc a vulputate lectus.
        </div>
    </div>
    <div class="b-some-examples__item_action">
        <div class="b-right">
            <a href="#" class="b-btn f-btn b-btn-sm f-btn-sm b-btn-default f-primary-b">book now</a>
        </div>
        <div class="b-remaining b-some-examples__item_total f-some-examples__item_total f-primary-b">From $1299</div>
    </div>
</div>
          </div>
        </div>
      </div>
    </section>
    <section class="b-google-map">
        <div class="f-primary-l f-center b-google-map__title f-google-map__title">find all <span class="f-primary-b">hotels</span> near you</div>
            <div class="b-google-map__map-view b-google-map__map-height">
    <!-- Google map load -->
</div>
<img data-retina src="" data-label="hotel name" class="marker-template hidden" />
<div class="b-google-map__info-window-template hidden"
     data-selected-marker="4"
     data-width="292">
    <div class="b-google-map__info-window col-xs-12 b-goggle-map_info-window-estate">
    <div class="b-goggle-map_info-window-estate-image">
        <img data-retina src="img/google-map-info-image.png" alt="">
    </div>
    <div class="f-google-map__info-window-estate-title clearfix">
        <div class="pull-left f-primary">Ocean View</div>
        <div class="pull-right f-primary-b">$320,000</div>
    </div>
    <div class="b-google-map__info-window-estate-details clearfix">
        <div class="b-right f-selection f-primary f-size-default">
    23 reviews
</div>
<div class="b-stars-group f-stars-group">
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star"></i>
</div>
    </div>
    <div class="f-primary f-google-map__info-window-estate-description">
        Vestibulum accumsan habitasse dictum id ut Curabitur amet libero mauris.
        <a class="f-more f-secondary-b" href="#">More info</a>
    </div>
</div>
</div>
        <div class="b-float-search__container b-float-search__container-without-background">
            <div class="b-float-search__container-inner b-float-search__container-inner-thick-round-border">
                <div class="b-float-search__container-inner-row  b-right-inner-addon f-right-inner-addon">
                    <i class="fa fa-map-marker b-left-inner-addon-marker f-left-inner-addon-marker"></i>
                    <i class="fa fa-search b-right-inner-addon-search"></i>
                    <input type="search" class="form-control b-float-search__input" placeholder="ENTER YOUR HOTEL" />
                </div>
            </div>
        </div>
    </section>
    <section class="b-infoblock b-diagonal-line-bg-light">
      <div class="container">
        <div class="b-carousel-secondary f-carousel-secondary b-carousel-reset">
          <div class="b-carousel-title f-carousel-title f-primary-b">popular hotels</div>
            <div class="b-some-examples f-some-examples f-some-examples-quaternary j-carousel-secondary">
                <div class="b-some-examples__item f-some-examples__item">
    <div class="b-some-examples__item_img view view-sixth">
    <img data-retina="" src="img/homepage/travel_img4.jpg" alt="">
    <div class="b-item-hover-action f-center mask">
        <div class="b-item-hover-action__inner">
            <div class="b-item-hover-action__inner-btn_group">
                <a href="#" class="b-btn f-btn b-btn-light f-btn-light info"><i class="fa fa-link"></i></a>
            </div>
        </div>
    </div>
</div>
    <div class="b-some-examples__item_info">
        <div class="b-some-examples__item_info_level b-some-examples__item_name f-some-examples__item_name f-primary-b"><a href="#">Tropicana hotel</a></div>
        <div class="b-some-examples__item_info_level b-some-examples__item_double_info f-some-examples__item_double_info clearfix">
            <div class="b-right f-selection f-primary f-size-default">
    23 reviews
</div>
<div class="b-stars-group f-stars-group">
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star"></i>
</div>
        </div>
        <div class="b-some-examples__item_info_level b-some-examples__item_description f-some-examples__item_description">
            Suspendisse blandit ligula turpis, ac convallis risus fermentum non. Duis vestibulum quis quam vel accumsan. Nunc a vulputate lectus.
        </div>
    </div>
    <div class="b-some-examples__item_action">
        <div class="b-right">
            <a href="#" class="b-btn f-btn b-btn-sm f-btn-sm b-btn-default f-primary-b">book now</a>
        </div>
        <div class="b-remaining b-some-examples__item_total f-some-examples__item_total f-primary-b">From $1299</div>
    </div>
</div>
                <div class="b-some-examples__item f-some-examples__item">
    <div class="b-some-examples__item_img view view-sixth">
    <img data-retina="" src="img/homepage/travel_img5.jpg" alt="">
    <div class="b-item-hover-action f-center mask">
        <div class="b-item-hover-action__inner">
            <div class="b-item-hover-action__inner-btn_group">
                <a href="#" class="b-btn f-btn b-btn-light f-btn-light info"><i class="fa fa-link"></i></a>
            </div>
        </div>
    </div>
</div>
    <div class="b-some-examples__item_info">
        <div class="b-some-examples__item_info_level b-some-examples__item_name f-some-examples__item_name f-primary-b"><a href="#">Tropicana hotel</a></div>
        <div class="b-some-examples__item_info_level b-some-examples__item_double_info f-some-examples__item_double_info clearfix">
            <div class="b-right f-selection f-primary f-size-default">
    23 reviews
</div>
<div class="b-stars-group f-stars-group">
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star"></i>
</div>
        </div>
        <div class="b-some-examples__item_info_level b-some-examples__item_description f-some-examples__item_description">
            Suspendisse blandit ligula turpis, ac convallis risus fermentum non. Duis vestibulum quis quam vel accumsan. Nunc a vulputate lectus.
        </div>
    </div>
    <div class="b-some-examples__item_action">
        <div class="b-right">
            <a href="#" class="b-btn f-btn b-btn-sm f-btn-sm b-btn-default f-primary-b">book now</a>
        </div>
        <div class="b-remaining b-some-examples__item_total f-some-examples__item_total f-primary-b">From $1299</div>
    </div>
</div>
                <div class="b-some-examples__item f-some-examples__item">
    <div class="b-some-examples__item_img view view-sixth">
    <img data-retina="" src="img/homepage/travel_img6.jpg" alt="">
    <div class="b-item-hover-action f-center mask">
        <div class="b-item-hover-action__inner">
            <div class="b-item-hover-action__inner-btn_group">
                <a href="#" class="b-btn f-btn b-btn-light f-btn-light info"><i class="fa fa-link"></i></a>
            </div>
        </div>
    </div>
</div>
    <div class="b-some-examples__item_info">
        <div class="b-some-examples__item_info_level b-some-examples__item_name f-some-examples__item_name f-primary-b"><a href="#">Tropicana hotel</a></div>
        <div class="b-some-examples__item_info_level b-some-examples__item_double_info f-some-examples__item_double_info clearfix">
            <div class="b-right f-selection f-primary f-size-default">
    23 reviews
</div>
<div class="b-stars-group f-stars-group">
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star"></i>
</div>
        </div>
        <div class="b-some-examples__item_info_level b-some-examples__item_description f-some-examples__item_description">
            Suspendisse blandit ligula turpis, ac convallis risus fermentum non. Duis vestibulum quis quam vel accumsan. Nunc a vulputate lectus.
        </div>
    </div>
    <div class="b-some-examples__item_action">
        <div class="b-right">
            <a href="#" class="b-btn f-btn b-btn-sm f-btn-sm b-btn-default f-primary-b">book now</a>
        </div>
        <div class="b-remaining b-some-examples__item_total f-some-examples__item_total f-primary-b">From $1299</div>
    </div>
</div>
                <div class="b-some-examples__item f-some-examples__item">
    <div class="b-some-examples__item_img view view-sixth">
    <img data-retina="" src="img/homepage/travel_img4.jpg" alt="">
    <div class="b-item-hover-action f-center mask">
        <div class="b-item-hover-action__inner">
            <div class="b-item-hover-action__inner-btn_group">
                <a href="#" class="b-btn f-btn b-btn-light f-btn-light info"><i class="fa fa-link"></i></a>
            </div>
        </div>
    </div>
</div>
    <div class="b-some-examples__item_info">
        <div class="b-some-examples__item_info_level b-some-examples__item_name f-some-examples__item_name f-primary-b"><a href="#">Tropicana hotel</a></div>
        <div class="b-some-examples__item_info_level b-some-examples__item_double_info f-some-examples__item_double_info clearfix">
            <div class="b-right f-selection f-primary f-size-default">
    23 reviews
</div>
<div class="b-stars-group f-stars-group">
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star"></i>
</div>
        </div>
        <div class="b-some-examples__item_info_level b-some-examples__item_description f-some-examples__item_description">
            Suspendisse blandit ligula turpis, ac convallis risus fermentum non. Duis vestibulum quis quam vel accumsan. Nunc a vulputate lectus.
        </div>
    </div>
    <div class="b-some-examples__item_action">
        <div class="b-right">
            <a href="#" class="b-btn f-btn b-btn-sm f-btn-sm b-btn-default f-primary-b">book now</a>
        </div>
        <div class="b-remaining b-some-examples__item_total f-some-examples__item_total f-primary-b">From $1299</div>
    </div>
</div>
                <div class="b-some-examples__item f-some-examples__item">
    <div class="b-some-examples__item_img view view-sixth">
    <img data-retina="" src="img/homepage/travel_img5.jpg" alt="">
    <div class="b-item-hover-action f-center mask">
        <div class="b-item-hover-action__inner">
            <div class="b-item-hover-action__inner-btn_group">
                <a href="#" class="b-btn f-btn b-btn-light f-btn-light info"><i class="fa fa-link"></i></a>
            </div>
        </div>
    </div>
</div>
    <div class="b-some-examples__item_info">
        <div class="b-some-examples__item_info_level b-some-examples__item_name f-some-examples__item_name f-primary-b"><a href="#">Tropicana hotel</a></div>
        <div class="b-some-examples__item_info_level b-some-examples__item_double_info f-some-examples__item_double_info clearfix">
            <div class="b-right f-selection f-primary f-size-default">
    23 reviews
</div>
<div class="b-stars-group f-stars-group">
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star"></i>
</div>
        </div>
        <div class="b-some-examples__item_info_level b-some-examples__item_description f-some-examples__item_description">
            Suspendisse blandit ligula turpis, ac convallis risus fermentum non. Duis vestibulum quis quam vel accumsan. Nunc a vulputate lectus.
        </div>
    </div>
    <div class="b-some-examples__item_action">
        <div class="b-right">
            <a href="#" class="b-btn f-btn b-btn-sm f-btn-sm b-btn-default f-primary-b">book now</a>
        </div>
        <div class="b-remaining b-some-examples__item_total f-some-examples__item_total f-primary-b">From $1299</div>
    </div>
</div>
                <div class="b-some-examples__item f-some-examples__item">
    <div class="b-some-examples__item_img view view-sixth">
    <img data-retina="" src="img/homepage/travel_img6.jpg" alt="">
    <div class="b-item-hover-action f-center mask">
        <div class="b-item-hover-action__inner">
            <div class="b-item-hover-action__inner-btn_group">
                <a href="#" class="b-btn f-btn b-btn-light f-btn-light info"><i class="fa fa-link"></i></a>
            </div>
        </div>
    </div>
</div>
    <div class="b-some-examples__item_info">
        <div class="b-some-examples__item_info_level b-some-examples__item_name f-some-examples__item_name f-primary-b"><a href="#">Tropicana hotel</a></div>
        <div class="b-some-examples__item_info_level b-some-examples__item_double_info f-some-examples__item_double_info clearfix">
            <div class="b-right f-selection f-primary f-size-default">
    23 reviews
</div>
<div class="b-stars-group f-stars-group">
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star is-active-stars"></i>
    <i class="fa fa-star"></i>
</div>
        </div>
        <div class="b-some-examples__item_info_level b-some-examples__item_description f-some-examples__item_description">
            Suspendisse blandit ligula turpis, ac convallis risus fermentum non. Duis vestibulum quis quam vel accumsan. Nunc a vulputate lectus.
        </div>
    </div>
    <div class="b-some-examples__item_action">
        <div class="b-right">
            <a href="#" class="b-btn f-btn b-btn-sm f-btn-sm b-btn-default f-primary-b">book now</a>
        </div>
        <div class="b-remaining b-some-examples__item_total f-some-examples__item_total f-primary-b">From $1299</div>
    </div>
</div>
            </div>
        </div>
      </div>
    </section>
    <section class="b-about-container f-about-container b-bg-street b-about-container__with-img-l b-about-container--high">
      <div class="container">
        <div class="b-about-container__img">
          <img data-retina src="img/animation-data/about-img2.png" alt="">
        </div>
        <div class="b-about-container__inner b-slider-reset b-slider-about">
          <div class="j-slider-primary">
            <div>
              <div class="b-about-container__title f-about-container__title f-primary-b">tell us your travel stories</div>
              <div class="b-about-container__title_second f-about-container__title_second f-primary-l">Lorem ipsum dolor sit amet, consectetur adiet
              </div>
              <div class="b-about-container__text f-about-container__text f-primary-l">
                Maecenas eros tellus, vulputate in felis eu, tristique lobortis nisl. Nullam ornare, justo sit amet cursus auctor, lorem lacus laoreet ante, nec lacinia diam urna ut justo. Pellentesque blandit iaculis justo, ut imperdiet metus eleifend nec. Aenean a vestibulum risus. Nulla vitae ultricies velit, et pulvinar mauris. Donec mattis sagittis enim. Vivamus ac sapien placerat nisi elementum Curabitur blandit tempus porttitor. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              </div>
            </div>
            <div>
              <div class="b-about-container__title f-about-container__title f-primary-b">tell us your travel stories</div>
              <div class="b-about-container__title_second f-about-container__title_second f-primary-l">Lorem ipsum dolor sit amet, consectetur adiet
              </div>
              <div class="b-about-container__text f-about-container__text f-primary-l">
                Maecenas eros tellus, vulputate in felis eu, tristique lobortis nisl. Nullam ornare, justo sit amet cursus auctor, lorem lacus laoreet ante, nec lacinia diam urna ut justo. Pellentesque blandit iaculis justo, ut imperdiet metus eleifend nec. Aenean a vestibulum risus. Nulla vitae ultricies velit, et pulvinar mauris. Donec mattis sagittis enim. Vivamus ac sapien placerat nisi elementum Curabitur blandit tempus porttitor. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              </div>
            </div>
            <div>
              <div class="b-about-container__title f-about-container__title f-primary-b">tell us your travel stories</div>
              <div class="b-about-container__title_second f-about-container__title_second f-primary-l">Lorem ipsum dolor sit amet, consectetur adiet
              </div>
              <div class="b-about-container__text f-about-container__text f-primary-l">
                Maecenas eros tellus, vulputate in felis eu, tristique lobortis nisl. Nullam ornare, justo sit amet cursus auctor, lorem lacus laoreet ante, nec lacinia diam urna ut justo. Pellentesque blandit iaculis justo, ut imperdiet metus eleifend nec. Aenean a vestibulum risus. Nulla vitae ultricies velit, et pulvinar mauris. Donec mattis sagittis enim. Vivamus ac sapien placerat nisi elementum Curabitur blandit tempus porttitor. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              </div>
            </div>
           </div>
        </div>
      </div>
    </section>
  </div>

  <footer>
  <div class="b-footer-primary">
    <div class="container">
        <div class="row">
            <div class="col-sm-4 col-xs-12 f-copyright b-copyright">Copyright © 2024 Rappel Extreme - Todos los derechos reservados</div>
            <div class="col-sm-8 col-xs-12">
                <div class="b-btn f-btn b-btn-default b-right b-footer__btn_up f-footer__btn_up j-footer__btn_up">
                    <i class="fa fa-chevron-up"></i>
                </div>
                <nav class="b-bottom-nav f-bottom-nav b-right hidden-xs">
                    <ul>
                        <li><a href="#">Inicio</a></li>
                        <li><a href="#">Actividades</a></li>
                        <li><a href="#">Galería</a></li>
                        <li><a href="#">Sobre Nosotros</a></li>
                        <li><a href="#">Contacto</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>
  <div class="container">
    <div class="b-footer-secondary row">
      <div class="col-md-3 col-sm-12 col-xs-12 f-center b-footer-logo-containter">
          <a href=""><img data-retina class="b-footer-logo color-theme" src="img/logo-vertical-default.jpg" alt="Logo"/></a>
          <div class="b-footer-logo-text f-footer-logo-text">
          <p>Mauris rhoncus pretium porttitor. Cras scelerisque commodo odio.</p>
          <div class="b-btn-group-hor f-btn-group-hor">
            <a href="#" class="b-btn-group-hor__item f-btn-group-hor__item">
              <i class="fa fa-twitter"></i>
            </a>
            <a href="#" class="b-btn-group-hor__item f-btn-group-hor__item">
              <i class="fa fa-facebook"></i>
            </a>
            <a href="#" class="b-btn-group-hor__item f-btn-group-hor__item">
              <i class="fa fa-dribbble"></i>
            </a>
            <a href="#" class="b-btn-group-hor__item f-btn-group-hor__item">
              <i class="fa fa-behance"></i>
            </a>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-12 col-xs-12">
        <h4 class="f-primary-b">Latest blog posts</h4>
        <div class="b-blog-short-post row">
          <div class="b-blog-short-post__item col-md-12 col-sm-4 col-xs-12 f-primary-b">
            <div class="b-blog-short-post__item_text f-blog-short-post__item_text">
              <a href="blog_detail_left_slidebar.html">Amazing post with all the goodies</a>
            </div>
            <div class="b-blog-short-post__item_date f-blog-short-post__item_date">
              March 23, 2013
            </div>
          </div>
          <div class="b-blog-short-post__item col-md-12 col-sm-4 col-xs-12 f-primary-b">
            <div class="b-blog-short-post__item_text f-blog-short-post__item_text">
              <a href="blog_detail_left_slidebar.html">Amazing post with all the goodies</a>
            </div>
            <div class="b-blog-short-post__item_date f-blog-short-post__item_date">
              March 23, 2013
            </div>
          </div>
          <div class="b-blog-short-post__item col-md-12 col-sm-4 col-xs-12 f-primary-b">
            <div class="b-blog-short-post__item_text f-blog-short-post__item_text">
              <a href="blog_detail_left_slidebar.html">Amazing post with all the goodies</a>
            </div>
            <div class="b-blog-short-post__item_date f-blog-short-post__item_date">
              March 23, 2013
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-12 col-xs-12">
        <h4 class="f-primary-b">contact info</h4>
        <div class="b-contacts-short-item-group">
          <div class="b-contacts-short-item col-md-12 col-sm-4 col-xs-12">
            <div class="b-contacts-short-item__icon f-contacts-short-item__icon f-contacts-short-item__icon_lg b-left">
              <i class="fa fa-map-marker"></i>
            </div>
            <div class="b-remaining f-contacts-short-item__text">
              Frexy Studio<br/>
                1234 Street Name, City Name,<br/>
                United States.<br/>
            </div>
          </div>
          <div class="b-contacts-short-item col-md-12 col-sm-4 col-xs-12">
            <div class="b-contacts-short-item__icon f-contacts-short-item__icon b-left f-contacts-short-item__icon_md">
              <i class="fa fa-skype"></i>
            </div>
            <div class="b-remaining f-contacts-short-item__text f-contacts-short-item__text_phone">
                Skype: ask.company
            </div>
          </div>
          <div class="b-contacts-short-item col-md-12 col-sm-4 col-xs-12">
            <div class="b-contacts-short-item__icon f-contacts-short-item__icon b-left f-contacts-short-item__icon_xs">
              <i class="fa fa-envelope"></i>
            </div>
            <div class="b-remaining f-contacts-short-item__text f-contacts-short-item__text_email">
              <a href="mailto:frexystudio@gmail.com">mail@example.com</a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-12 col-xs-12 ">
        <h4 class="f-primary-b">photo stream</h4>
          <div class="b-short-photo-items-group">
    <div class="b-column">
        <a class="b-short-photo-item fancybox" href="img/gallery/big/gallery_1.jpg" title="photo stream" rel="footer-group"><img width="62" height="62" data-retina src="img/gallery/sm/gallery_1.jpg" alt=""/></a>
    </div>
    <div class="b-column">
        <a class="b-short-photo-item fancybox" href="img/gallery/big/gallery_2.jpg" title="photo stream" rel="footer-group"><img width="62" height="62" data-retina src="img/gallery/sm/gallery_2.jpg" alt=""/></a>
    </div>
    <div class="b-column">
        <a class="b-short-photo-item fancybox" href="img/gallery/big/gallery_3.jpg" title="photo stream" rel="footer-group"><img width="62" height="62" data-retina src="img/gallery/sm/gallery_3.jpg" alt=""/></a>
    </div>
    <div class="b-column">
        <a class="b-short-photo-item fancybox" href="img/gallery/big/gallery_4.jpg" title="photo stream" rel="footer-group"><img width="62" height="62" data-retina src="img/gallery/sm/gallery_4.jpg" alt=""/></a>
    </div>
    <div class="b-column">
        <a class="b-short-photo-item fancybox" href="img/gallery/big/gallery_5.jpg" title="photo stream" rel="footer-group"><img width="62" height="62" data-retina src="img/gallery/sm/gallery_5.jpg" alt=""/></a>
    </div>
    <div class="b-column">
        <a class="b-short-photo-item fancybox" href="img/gallery/big/gallery_6.jpg" title="photo stream" rel="footer-group"><img width="62" height="62" data-retina src="img/gallery/sm/gallery_6.jpg" alt=""/></a>
    </div>
    <div class="b-column">
        <a class="b-short-photo-item fancybox" href="img/gallery/big/gallery_7.jpg" title="photo stream" rel="footer-group"><img width="62" height="62" data-retina src="img/gallery/sm/gallery_7.jpg" alt=""/></a>
    </div>
    <div class="b-column">
        <a class="b-short-photo-item fancybox" href="img/gallery/big/gallery_8.jpg" title="photo stream" rel="footer-group"><img width="62" height="62" data-retina src="img/gallery/sm/gallery_8.jpg" alt=""/></a>
    </div>
    <div class="b-column hidden-xs">
        <a class="b-short-photo-item fancybox" href="img/gallery/big/gallery_9.jpg" title="photo stream" rel="footer-group"><img width="62" height="62" data-retina src="img/gallery/sm/gallery_9.jpg" alt=""/></a>
    </div>
    <div class="b-column hidden-sm hidden-xs">
        <a class="b-short-photo-item fancybox" href="img/gallery/big/gallery_10.jpg" title="photo stream" rel="footer-group"><img width="62" height="62" data-retina src="img/gallery/sm/gallery_10.jpg" alt=""/></a>
    </div>
    <div class="b-column hidden-sm hidden-xs">
        <a class="b-short-photo-item fancybox" href="img/gallery/big/gallery_11.jpg" title="photo stream" rel="footer-group"><img width="62" height="62" data-retina src="img/gallery/sm/gallery_11.jpg" alt=""/></a>
    </div>
    <div class="b-column hidden-sm hidden-xs">
        <a class="b-short-photo-item fancybox" href="img/gallery/big/gallery_12.jpg" title="photo stream" rel="footer-group"><img width="62" height="62" data-retina src="img/gallery/sm/gallery_12.jpg" alt=""/></a>
    </div>
</div>
      </div>
    </div>
  </div>
</footer>
<script src="js/breakpoints.js"></script>
<script src="js/jquery/jquery-1.11.1.min.js"></script>
<!-- bootstrap -->
<script src="js/scrollspy.js"></script>
<script src="js/bootstrap-progressbar/bootstrap-progressbar.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- end bootstrap -->
<script src="js/masonry.pkgd.min.js"></script>
<script src='js/imagesloaded.pkgd.min.js'></script>
<!-- bxslider -->
<script src="js/bxslider/jquery.bxslider.min.js"></script>
<!-- end bxslider -->
<!-- flexslider -->
<script src="js/flexslider/jquery.flexslider.js"></script>
<!-- end flexslider -->
<!-- smooth-scroll -->
<script src="js/smooth-scroll/SmoothScroll.js"></script>
<!-- end smooth-scroll -->
<!-- carousel -->
<script src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
<!-- end carousel -->
<script src="js/rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
<script src="js/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
<script src="js/rs-plugin/videojs/video.js"></script>

<!-- jquery ui -->
<script src="js/jqueryui/jquery-ui.js"></script>
<!-- end jquery ui -->
<script type="text/javascript" language="javascript"
        src="http://maps.google.com/maps/api/js?sensor=false&key=AIzaSyCfVS1-Dv9bQNOIXsQhTSvj7jaDX7Oocvs"></script>
<!-- Modules -->
<script src="js/modules/sliders.js"></script>
<script src="js/modules/ui.js"></script>
<script src="js/modules/retina.js"></script>
<script src="js/modules/animate-numbers.js"></script>
<script src="js/modules/parallax-effect.js"></script>
<script src="js/modules/settings.js"></script>
<script src="js/modules/maps-google.js"></script>
<script src="js/modules/color-themes.js"></script>
<!-- End Modules -->

<!-- Audio player -->
<script type="text/javascript" src="js/audioplayer/js/jquery.jplayer.min.js"></script>
<script type="text/javascript" src="js/audioplayer/js/jplayer.playlist.min.js"></script>
<script src="js/audioplayer.js"></script>
<!-- end Audio player -->

<!-- radial Progress -->
<script src="js/radial-progress/jquery.easing.1.3.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/d3/3.4.13/d3.min.js"></script>
<script src="js/radial-progress/radialProgress.js"></script>
<script src="js/progressbars.js"></script>
<!-- end Progress -->

<!-- Google services -->
<script type="text/javascript" src="https://www.google.com/jsapi?autoload={'modules':[{'name':'visualization','version':'1','packages':['corechart']}]}"></script>
<script src="js/google-chart.js"></script>
<!-- end Google services -->
<script src="js/j.placeholder.js"></script>

<!-- Fancybox -->
<script src="js/fancybox/jquery.fancybox.pack.js"></script>
<script src="js/fancybox/jquery.mousewheel.pack.js"></script>
<script src="js/fancybox/jquery.fancybox.custom.js"></script>
<!-- End Fancybox -->
<script src="js/user.js"></script>
<script src="js/timeline.js"></script>
<script src="js/fontawesome-markers.js"></script>
<script src="js/markerwithlabel.js"></script>
<script src="js/cookie.js"></script>
<script src="js/loader.js"></script>
<script src="js/scrollIt/scrollIt.min.js"></script>
<script src="js/modules/navigation-slide.js"></script>

</body>
</html>